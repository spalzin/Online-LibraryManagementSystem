<?php 
include 'connection.php';
$rn=$_GET['rn'];
$sql="";

?>